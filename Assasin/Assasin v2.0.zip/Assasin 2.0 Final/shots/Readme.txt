This is a temporary directory where screenshots and webcam shots will
be held for decompressing!